# An empty function to allow quiet mode

quietcat <- function(...) NULL
