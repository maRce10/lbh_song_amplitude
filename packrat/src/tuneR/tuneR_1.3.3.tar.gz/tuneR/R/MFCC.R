MFCC <- 
function(...)
{
    .Defunct("melfcc", package="tuneR", "'MFCC' is defunct. Use 'melfcc' instead.")
}
